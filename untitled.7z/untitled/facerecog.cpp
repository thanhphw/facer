#include "facerecog.h"
#include "homescreen.h"
#include "takepicture.h"
#include "ui_facerecog.h"
#include "socketcom.h"
#include "selectfacerecog.h"
facerecog::facerecog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::facerecog)
{
    ui->setupUi(this);
}

facerecog::~facerecog()
{
    delete ui;
}

void facerecog::on_BtnBackFaceR_clicked()
{
    homescreen *wHome = new homescreen();
    wHome->move(100,200);
    wHome->show();
    this->close();
}

void facerecog::on_BtnTakePicture_clicked()
{
    takepicture *wTP = new takepicture();
    wTP->move(100,200);
    wTP->show();
    this->close();
}

void facerecog::on_BtnTrainModel_clicked()
{
    socketcom *sk;
    sk->sendDataToPython(1236, "train_signal");
}

void facerecog::on_BtnOpenCamera_clicked()
{
    selectfacerecog *wSFR = new selectfacerecog();
    wSFR->move(100,200);
    wSFR->show();
    this->close();
}




