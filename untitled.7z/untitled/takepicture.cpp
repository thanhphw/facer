#include "takepicture.h"
#include "facerecog.h"
#include "ui_takepicture.h"
#include "socketcom.h"

#include <QString>
#include <QProcess>

takepicture::takepicture(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::takepicture)
{
    ui->setupUi(this);
}

takepicture::~takepicture()
{
    delete ui;
}

void takepicture::on_btnBackTP_clicked()
{
    facerecog *wFaceR = new facerecog();
    wFaceR->move(100,200);
    wFaceR->show();
    this->close();
}

void takepicture::on_btnOpenCameraTP_clicked()
{
    QString qstrInputName = ui->txteNameTP->text();
    QProcess QPro_run1;
    QString command1 = "mkdir dataset/" + qstrInputName;
    QPro_run1.start(command1);

    QPro_run1.waitForFinished();

    socketcom *sk;
    sk->sendDataToPython(1235, qstrInputName);
}
