#include "manageface.h"

manageFace::manageFace()
{

}

bool manageFace::addUser(QString name, inforUser info)
{
    if (ListUser.find(name) != ListUser.end())
    {
        // ID already exists, do not accept to add new account
        return false;
    }

    ListUser[name] = info;

    // Account added successfully
    return true;
}

bool manageFace::removeUser(QString name)
{
    if (ListUser.find(name) != ListUser.end())
    {
        ListUser.erase(name);
        return true;
    }
    return false;
}

inforUser manageFace::getInforUser(QString name)
{
    if (ListUser.find(name) != ListUser.end())
    {
        return ListUser[name];
    }
    return {"", 0, ""};
}

