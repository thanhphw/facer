#include "changepassword.h"
#include "ui_changepassword.h"
#include "accountinfo.h"
#include <QVBoxLayout>

changepassword::changepassword(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::changepassword)
{
    ui->setupUi(this);
}

changepassword::~changepassword()
{
    delete ui;
}

void changepassword::hideAllControlChangePass()
{
    ui->btnBack->hide();
    ui->btnConf->hide();
    ui->label->hide();
    ui->label_2->hide();
    ui->label_3->hide();
    ui->label_4->hide();
    ui->txteOldPass->hide();
    ui->txteNewPass->hide();
    ui->txteConfPass->hide();
}

void changepassword::on_btnBack_clicked()
{
//    this->hideAllControlChangePass();
//    QVBoxLayout *layout1 = new QVBoxLayout(this);
//    setLayout(layout1);
//    accountinfo* wHome1 = new accountinfo;
//    layout1->addWidget(wHome1);
//    wHome1->show();
    homescreen *wHome = new homescreen();
    wHome->move(100,200);
    wHome->show();

    this->close();
}
