#ifndef TAKEPICTURE_H
#define TAKEPICTURE_H

#include <QWidget>

namespace Ui {
class takepicture;
}

class takepicture : public QWidget
{
    Q_OBJECT

public:
    explicit takepicture(QWidget *parent = nullptr);
    ~takepicture();

private slots:
    void on_btnBackTP_clicked();

    void on_btnOpenCameraTP_clicked();

private:
    Ui::takepicture *ui;
};

#endif // TAKEPICTURE_H
