#include <QProcess>
#include <QtNetwork/QTcpSocket>
#include "mainwindow.h"
#include "./ui_mainwindow.h"

void sendDataToPython(int nSocket, QString qstrInputName)
{
    QTcpSocket socket1;
    socket1.connectToHost("localhost", nSocket); // Replace with the appropriate IP address and port number

    if (socket1.waitForConnected()) {
        QByteArray data = qstrInputName.toUtf8();
        // Prepare the data to be sent
        // ...

        // Send the data
        socket1.write(data);
        socket1.waitForBytesWritten();
        socket1.disconnectFromHost();
    }
}
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_BtnFaceShot_clicked()
{


    QString qstrInputName = ui->TxteInputName->toPlainText();
    QProcess QPro_run1;
    QString command1 = "./facerec/" + qstrInputName;
    QPro_run1.start(command1);

    QPro_run1.waitForFinished();
    sendDataToPython(1235, qstrInputName);

//    QProcess QPro_run;
//    QString command = "python3";
//    QStringList arguments;

//    arguments << "face_shot.py";

//    QPro_run.start(command, arguments);
//    sendDataToPython(qstrInputName);
//    QPro_run.waitForFinished();


}

void MainWindow::on_BtnTrainModel_clicked()
{
//    QProcess QPro_run;
//    QString command = "python3";
//    QStringList arguments;
//    arguments << "train_model.py";

//    QPro_run.start(command, arguments);

//    QPro_run.waitForFinished();
    sendDataToPython(1236, "train_signal");
}

void MainWindow::on_BtnFaceRec_clicked()
{
//    QProcess QPro_run;
//    QString command = "python3";
//    QStringList arguments;
//    arguments << "face_rec.py";

//    QPro_run.start(command, arguments);

//    QObject::connect(&QPro_run, &QProcess::readyReadStandardOutput, [&](){
//        qDebug("hihi");
//    });

//    QPro_run.waitForFinished();
    sendDataToPython(1238, "open_facerecog");
}
