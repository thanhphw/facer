#ifndef HOMESCREEN_H
#define HOMESCREEN_H
#include "accountinfo.h"
#include <QDialog>

namespace Ui {
class homescreen;
}

class homescreen : public QDialog
{
    Q_OBJECT

public:
    //accountinfo* wAcc;

public:
    explicit homescreen(QWidget *parent = nullptr);
    ~homescreen();
    void hideAllControlHome();
    void hideAllControlAccountInfo();

private slots:
    void on_BtnFaceRecog_clicked();

    void on_BtnHistory_clicked();

    void on_BtnManageData_clicked();

    void on_BtnAccountInfo_clicked();

private:
    Ui::homescreen *ui;
};

#endif // HOMESCREEN_H
