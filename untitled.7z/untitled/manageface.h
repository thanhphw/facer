#include <map>
#include <vector>
#include <QString>
#ifndef MANAGEFACE_H
#define MANAGEFACE_H


typedef struct inforUser
{
    QString Image;
    int age;
    QString desc;
} inforUser;

class manageFace
{
public:
    manageFace();
    bool addUser(QString name, inforUser info);
    bool removeUser(QString name);
    inforUser getInforUser(QString name);

    std::map<QString,inforUser> ListUser;

};

#endif // MANAGEFACE_H
