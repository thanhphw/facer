#ifndef LOGINSCREEN_H
#define LOGINSCREEN_H

#include <QDialog>

namespace Ui {
class loginscreen;
}

class loginscreen : public QDialog
{
    Q_OBJECT

public:
    explicit loginscreen(QWidget *parent = nullptr);
    ~loginscreen();
    int getIsLoginScreen();
    void setIsLoginScreen(bool);
    void notifyAccountAddedSuccessfully();

private slots:
    void on_BtnOkLogin_clicked();
    void updateCapsLockState();
    void openRegisterScreen();
    void openLoginScreen();
    void on_BtnRegisterLogin_clicked();
    void on_BtnCancelRegistor_clicked();

    void on_BtnOkRegistor_clicked();

private:
    void AddAccountFromRegistor();

private:
    Ui::loginscreen *ui;
    bool isLoginScreen;
};

#endif // LOGINSCREEN_H
