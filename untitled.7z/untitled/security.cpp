#include <QFile>
#include <QTextStream>
#include <QPixmap>
#include <QMessageBox>
#include "security.h"

security::security()
{
    // Load list account
    restoreListAccountFromTxt("log.txt");
}

/*
*   return true if add successfully
*
*/
bool security::addAccount(QString ID, QString Pass)
{
    if (ListAccount.find(ID) != ListAccount.end())
    {
        // ID already exists, do not accept to add new account
        return false;
    }

    ListAccount[ID] = Pass;
    storeListAccountInTxt("log.txt");
    // Account added successfully
    return true;
}

/*
*   return true if login successfully by password and ID valid
*
*/
bool security::loginAccount(QString ID, QString Pass)
{
    if (ListAccount.find(ID) != ListAccount.end())
    {
        QString storedPass = ListAccount[ID];
        if (storedPass == Pass)
        {
            // ID exists and password matches
            return true;
        }
    }

    // ID does not exist or password does not match
    return false;
}

void security::restoreListAccountFromTxt(const QString& fileName)
{
    QFile file("/home/phuongtt47/Desktop/FaceRecog/untitled/log.txt");

    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream in(&file);

        while (!in.atEnd())
        {
            QString line = in.readLine();
            QStringList parts = line.split(':');

            if (parts.size() == 2)
            {
                QString ID = parts[0].trimmed();
                QString Pass = parts[1].trimmed();

                ListAccount[ID] = Pass;
            }
        }

        file.close();
    }
    else
    {

    }
}

void security::storeListAccountInTxt(const QString& fileName)
{
    QFile file("/home/phuongtt47/Desktop/FaceRecog/untitled/log.txt");

    if (file.open(QIODevice::Append | QIODevice::Text))
    {
        QTextStream out(&file);

        for (const auto& pair : ListAccount)
        {
            QString line = pair.first + ":" + pair.second;
            out << line << endl;
        }

        file.close();
    }
    else
    {

    }
}


