#include "mainwindow.h"
#include "loginscreen.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    loginscreen lm;
    lm.show();
    return a.exec();
}
