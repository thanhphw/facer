#ifndef ACCOUNTINFO_H
#define ACCOUNTINFO_H

#include <QDialog>
#include "homescreen.h"

namespace Ui {
class accountinfo;
}

class accountinfo : public QDialog
{
    Q_OBJECT

public:
    explicit accountinfo(QWidget *parent = nullptr);
    ~accountinfo();
    void hideAllControlAccountInf();
private slots:
    void on_BtnBackAccountInfo_clicked();

    void on_BtnChangePass_clicked();

private:
    Ui::accountinfo *ui;
    //homescreen* wHome;
};

#endif // ACCOUNTINFO_H
