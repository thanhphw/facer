#ifndef CHECKCAPSLOCK_H
#define CHECKCAPSLOCK_H


class checkCapsLock
{
public:
    checkCapsLock();
    bool check();
};

#endif // CHECKCAPSLOCK_H
