#ifndef LOGIN_SCREEN_H
#define LOGIN_SCREEN_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace uiLoginScreen { class login_screen; }
QT_END_NAMESPACE

class login_screen : public QDialog
{
    Q_OBJECT
public:
    login_screen(QWidget *parent = nullptr);
    ~login_screen();

private:
    uiLoginScreen::login_screen *uiLoginScreenInstance;
};

#endif // LOGIN_SCREEN_H
