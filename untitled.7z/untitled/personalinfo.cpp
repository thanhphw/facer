#include "personalinfo.h"
#include "managedata.h"
#include "showimage.h"
#include "ui_personalinfo.h"

#include <QVBoxLayout>
#include <QString>
#include <QLabel>
#include <QPixmap>
#include <QWidget>
#include <QDebug>
PersonalInfo::PersonalInfo(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::PersonalInfo)
{
    ui->setupUi(this);
//    QString image_path = "/home/phuongtt47/Desktop/FaceRecog/build-untitled-Desktop-Debug/dataset/PhuongTT/image_0.jpg";  // Replace with the actual path to your image
//    showimage widget1(image_path);
//    widget1.show();
}

PersonalInfo::~PersonalInfo()
{
    delete ui;
}

void PersonalInfo::on_btnBackPI_clicked()
{
    managedata *wManageD = new managedata();
    wManageD->show();
    wManageD->move(100,200);
    this->close();

}




void set_image(const QString& image_path, QLabel* label) {
    QPixmap pixmap(image_path);
    if (pixmap.isNull()) {
        qDebug("Failed to load");
    }
    label->setPixmap(pixmap);
    label->setScaledContents(true);
}
