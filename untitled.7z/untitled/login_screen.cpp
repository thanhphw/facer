#include "login_screen.h"
#include "mainwindow.h"
#include "./ui_login_screen.h"

login_screen::login_screen(QWidget *parent)
    : QDialog(parent)
    , uiLoginScreenInstance(new uiLoginScreen::login_screen)
{
    uiLoginScreenInstance->setupUi(this);
}


login_screen::~login_screen()
{
    delete uiLoginScreenInstance;
}
