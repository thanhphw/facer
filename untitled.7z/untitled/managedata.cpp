#include "managedata.h"
#include "homescreen.h"
#include "personalinfo.h"
#include "ui_managedata.h"

managedata::managedata(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::managedata)
{
    ui->setupUi(this);
}

managedata::~managedata()
{
    delete ui;
}

void managedata::on_BtnBackManage_clicked()
{
    homescreen *wHome = new homescreen();
    wHome->move(100,200);
    wHome->show();

    this->close();
}

void managedata::on_BtnModifyMana_clicked()
{
    PersonalInfo *wPers = new PersonalInfo();
    wPers->move(100,200);
    wPers->show();

    this->close();
}
