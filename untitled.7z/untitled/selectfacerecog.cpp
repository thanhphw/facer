#include <QProcess>
#include "selectfacerecog.h"
#include "facerecog.h"
#include "socketcom.h"
#include "ui_selectfacerecog.h"

selectfacerecog::selectfacerecog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::selectfacerecog)
{
    ui->setupUi(this);
}

selectfacerecog::~selectfacerecog()
{
    delete ui;
}

void selectfacerecog::on_BtnNeuralNetworkSFR_clicked()
{
    socketcom *sk;
    sk->sendDataToPython(1238, "open_facerecog");
}

void selectfacerecog::on_BtnLBPHSFR_clicked()
{
    socketcom *sk;
    sk->sendDataToPython(1239, "open_facerecog cpp");
    sk->sendDataToPython(1239, "");

}

void selectfacerecog::on_BtnBackSFR_clicked()
{
    facerecog *wFaceR = new facerecog();
    wFaceR->move(100,200);
    wFaceR->show();
    this->close();
}
