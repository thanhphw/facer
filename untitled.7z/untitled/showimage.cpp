#include "showimage.h"
#include <QVBoxLayout>
#include <QString>
#include <QLabel>
#include <QPixmap>
#include <QWidget>
#include <QDebug>

showimage::showimage(const QString& image_path)
{
    setWindowTitle("Image Display");

    QVBoxLayout* layout = new QVBoxLayout(this);
    QLabel* label = new QLabel(this);
    layout->addWidget(label);

    set_image(image_path, label);
    // Set the position of the QLabel
    label->move(500, 200);
}

void showimage::set_image(const QString& image_path, QLabel* label) {
    QPixmap pixmap(image_path);
    if (pixmap.isNull()) {
        qDebug("Failed to load");
    }
    label->setPixmap(pixmap);
    label->setScaledContents(true);
}

