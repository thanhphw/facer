#ifndef MANAGEDATA_H
#define MANAGEDATA_H

#include <QWidget>

namespace Ui {
class managedata;
}

class managedata : public QWidget
{
    Q_OBJECT

public:
    explicit managedata(QWidget *parent = nullptr);
    ~managedata();

private slots:
    void on_BtnBackManage_clicked();

    void on_BtnModifyMana_clicked();

private:
    Ui::managedata *ui;
};

#endif // MANAGEDATA_H
