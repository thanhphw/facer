#include "accountinfo.h"
#include "ui_accountinfo.h"
#include <QDialog>
#include "homescreen.h"
#include "changepassword.h"
#include <QDebug>
#include <QVBoxLayout>
#include <QRect>

accountinfo::accountinfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::accountinfo)
{
    ui->setupUi(this);

}

accountinfo::~accountinfo()
{
    delete ui;
}

void accountinfo::hideAllControlAccountInf()
{
    ui->groupBox_Account->hide();
    ui->lblFullName->hide();
    ui->lblStatus->hide();
    ui->groupBox_Account->setParent(nullptr);
    delete ui->groupBox_Account;
    ui->lblFullName->setParent(nullptr);
    delete ui->lblFullName;
    ui->lblStatus->setParent(nullptr);
    delete ui->lblStatus;
}

void accountinfo::on_BtnBackAccountInfo_clicked()
{
    //qDebug("Back button");

    homescreen *wHome = new homescreen();
    wHome->move(100,200);
    wHome->show();
    this->close();
}

void accountinfo::on_BtnChangePass_clicked()
{
    changepassword* wCP = new changepassword;
    wCP->move(100,200);
    wCP->show();
    this->close();
}
