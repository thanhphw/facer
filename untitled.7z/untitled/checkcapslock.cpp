#include "checkcapslock.h"
#include <X11/XKBlib.h>
#include <X11/Xlib.h>

checkCapsLock::checkCapsLock()
{

}

bool checkCapsLock::check()
{
    Display *d = XOpenDisplay((char*)0);
    bool caps_state = false;
    if (d)
    {
        unsigned int n;
        XkbGetIndicatorState(d, XkbUseCoreKbd, &n);
        caps_state = (n & 0x01) == 1;
    }
    return caps_state;
}
