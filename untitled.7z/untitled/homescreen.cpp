#include <QVBoxLayout>

#include "homescreen.h"
#include "facerecog.h"
#include "managedata.h"
#include "accountinfo.h"
#include "ui_homescreen.h"
#include "ui_accountinfo.h"

homescreen::homescreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::homescreen)
{
    ui->setupUi(this);
}

homescreen::~homescreen()
{
    delete ui;
}

void homescreen::hideAllControlHome()
{
    ui->groupBox_Home->hide();
    ui->lblTitleHome1->hide();
    ui->lblTitleHome2->hide();
    ui->groupBox_Home->setParent(nullptr);
    delete ui->groupBox_Home;
    ui->lblTitleHome1->setParent(nullptr);
    delete ui->lblTitleHome1;
    ui->lblTitleHome2->setParent(nullptr);
    delete ui->lblTitleHome2;
}

void homescreen::hideAllControlAccountInfo()
{
//    ui->groupBox_Account->hide();
//    ui->lblFullName->hide();
//    ui->lblStatus->hide();
}

void homescreen::on_BtnFaceRecog_clicked()
{
    facerecog *wFaceR = new facerecog();
    wFaceR->move(100,200);
    wFaceR->show();
    this->close();
}

void homescreen::on_BtnHistory_clicked()
{

}

void homescreen::on_BtnManageData_clicked()
{
    managedata *wManageD = new managedata();
    wManageD->move(100,200);
    wManageD->show();

    this->close();
}

void homescreen::on_BtnAccountInfo_clicked()
{
//    hideAllControlHome();

//    QVBoxLayout *layout = new QVBoxLayout(this);
//    setLayout(layout);
    accountinfo* wAcc = new accountinfo();
    wAcc->move(100, 200);
//    layout->addWidget(wAcc);
    wAcc->show();
    this->close();
    //ui->groupBox_Home->setGeometry(200,180,361,341);
}


