#include "socketcom.h"
#include <QProcess>
#include <QtNetwork/QTcpSocket>
socketcom::socketcom()
{

}


void socketcom::sendDataToPython(int nSocket, QString qstrInputName)
{
    QTcpSocket socket1;
    socket1.connectToHost("localhost", nSocket); // Replace with the appropriate IP address and port number

    if (socket1.waitForConnected()) {
        QByteArray data = qstrInputName.toUtf8();
        socket1.write(data);
        socket1.waitForBytesWritten();
        socket1.disconnectFromHost();
    }
}
