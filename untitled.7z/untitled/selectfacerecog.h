#ifndef SELECTFACERECOG_H
#define SELECTFACERECOG_H

#include <QWidget>

namespace Ui {
class selectfacerecog;
}

class selectfacerecog : public QWidget
{
    Q_OBJECT

public:
    explicit selectfacerecog(QWidget *parent = nullptr);
    ~selectfacerecog();

private slots:
    void on_BtnNeuralNetworkSFR_clicked();

    void on_BtnLBPHSFR_clicked();

    void on_BtnBackSFR_clicked();

private:
    Ui::selectfacerecog *ui;
};

#endif // SELECTFACERECOG_H
