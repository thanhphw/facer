#ifndef PERSONALINFO_H
#define PERSONALINFO_H

#include <QWidget>

namespace Ui {
class PersonalInfo;
}

class PersonalInfo : public QWidget
{
    Q_OBJECT

public:
    explicit PersonalInfo(QWidget *parent = nullptr);
    ~PersonalInfo();

private slots:
    void on_btnBackPI_clicked();

private:
    Ui::PersonalInfo *ui;
};

#endif // PERSONALINFO_H
