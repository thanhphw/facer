#ifndef FACERECOG_H
#define FACERECOG_H

#include <QWidget>

namespace Ui {
class facerecog;
}

class facerecog : public QWidget
{
    Q_OBJECT

public:
    explicit facerecog(QWidget *parent = nullptr);
    ~facerecog();

private slots:
    void on_BtnBackFaceR_clicked();

    void on_BtnTakePicture_clicked();

    void on_BtnTrainModel_clicked();

    void on_BtnOpenCamera_clicked();

private:
    Ui::facerecog *ui;
};

#endif // FACERECOG_H
