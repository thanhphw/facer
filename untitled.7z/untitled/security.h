#ifndef SECURITY_H
#define SECURITY_H
#include <map>
#include <QString>
class security
{
public:
    security();
    bool addAccount(QString ID, QString Pass);
    bool loginAccount(QString ID, QString Pass);
    void restoreListAccountFromTxt(const QString& fileName);
    void storeListAccountInTxt(const QString& fileName);

private:
    std::map<QString, QString> ListAccount;

};

#endif // SECURITY_H
