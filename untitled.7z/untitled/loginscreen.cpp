#include <QTimer>
#include <QMessageBox>
#include <QPixmap>
#include "loginscreen.h"
#include "ui_loginscreen.h"
#include "mainwindow.h"
#include "security.h"
#include "checkcapslock.h"
#include "homescreen.h"

loginscreen::loginscreen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::loginscreen)
{
    ui->setupUi(this);
    ui->TxtePass->setEchoMode(QLineEdit::Password);
    ui->TxtePassConf->setEchoMode(QLineEdit::Password);

    isLoginScreen = true;
    openLoginScreen();

    QTimer *timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateCapsLockState()));
    timer->start(500); // Check every 1 second

}

loginscreen::~loginscreen()
{
    delete ui;
}

void loginscreen::on_BtnOkLogin_clicked()
{
    security *securityInLoginScreen = new security();
    securityInLoginScreen->restoreListAccountFromTxt("log.txt");
    securityInLoginScreen->addAccount("Phuong", "123");
    QString strID = ui->TxteID->text();
    QString strPass = ui->TxtePass->text();

    bool isLoginSuccess = securityInLoginScreen->loginAccount(strID, strPass);

    if (isLoginSuccess == true)
    {
        this->close();
        homescreen *wHome = new homescreen();
        wHome->move(100,200);
        wHome->show();
    }
    else
    {
        qDebug("login failed");
    }
}

void loginscreen::on_BtnRegisterLogin_clicked()
{
    if (getIsLoginScreen() == true)
    {
       openRegisterScreen();
       setIsLoginScreen(false);
    }
    else
    {
        openLoginScreen();
        setIsLoginScreen(true);
    }
}

void loginscreen::on_BtnCancelRegistor_clicked()
{
    if (getIsLoginScreen() == false)
    {
       openLoginScreen();
       setIsLoginScreen(true);
    }
}

void loginscreen::updateCapsLockState()
{
    checkCapsLock ccl;
    bool capsLockState = ccl.check();
    if (capsLockState)
    {
        ui->lblCapsLockNotif->setText("Caps Lock is ON");
    }
    else
    {
        ui->lblCapsLockNotif->setText("");
    }
}


void loginscreen::openLoginScreen()
{
    ui->BtnOkRegistor->hide();
    ui->BtnCancelRegistor->hide();
    ui->TxtePassConf->hide();
    ui->lblConfPass->hide();
    ui->BtnOkLogin->show();
    ui->BtnCancelLogin->show();
    ui->BtnRegisterLogin->show();
    ui->lblHaveAcc->show();
    ui->TxteID->clear();
    ui->TxtePass->clear();
    ui->TxtePassConf->clear();
}

void loginscreen::openRegisterScreen()
{
    ui->BtnOkLogin->hide();
    ui->BtnCancelLogin->hide();
    ui->BtnRegisterLogin->hide();
    ui->BtnOkRegistor->show();
    ui->BtnCancelRegistor->show();
    ui->TxtePassConf->show();
    ui->lblConfPass->show();
    ui->lblHaveAcc->hide();
    ui->TxteID->clear();
    ui->TxtePass->clear();
    ui->TxtePassConf->clear();
}

void loginscreen::AddAccountFromRegistor()
{
    security *securityInLoginScreen = new security();
    QString strID = ui->TxteID->text();
    QString strPass = ui->TxtePass->text();
    QString strConfPass = ui->TxtePassConf->text();

    if (strPass == strConfPass)
    {
        securityInLoginScreen->addAccount(strID, strPass);
        this->notifyAccountAddedSuccessfully();
    }
    else
    {
        qDebug("Pass not match");
    }
    delete(securityInLoginScreen);
}

int loginscreen::getIsLoginScreen()
{
    return isLoginScreen;
}

void loginscreen::setIsLoginScreen(bool state)
{
    isLoginScreen = state;
}

void loginscreen::on_BtnOkRegistor_clicked()
{
    AddAccountFromRegistor();
}

void loginscreen::notifyAccountAddedSuccessfully()
{
    QMessageBox msgBox(this);
    msgBox.setWindowTitle("Account Added");
    msgBox.setText("Account has been added successfully!");

    // Set a custom icon
    QPixmap icon("/home/phuongtt47/Desktop/FaceRecog/build-untitled-Desktop-Debug/icon/success.png");
    msgBox.setIconPixmap(icon.scaled(64, 64)); // Adjust the size as needed

    msgBox.exec();
}


