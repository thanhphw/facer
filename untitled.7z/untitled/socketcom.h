#ifndef SOCKETCOM_H
#define SOCKETCOM_H
#include <QString>
class socketcom
{
public:
    socketcom();
    void sendDataToPython(int nSocket, QString qstrInputName);
};

#endif // SOCKETCOM_H
