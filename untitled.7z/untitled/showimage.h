#ifndef SHOWIMAGE_H
#define SHOWIMAGE_H
#include <QWidget>
#include <QString>
#include <QLabel>

class showimage : public QWidget
{
public:
    showimage(const QString& image_path);
    void set_image(const QString& image_path, QLabel* label);
};

#endif // SHOWIMAGE_H
