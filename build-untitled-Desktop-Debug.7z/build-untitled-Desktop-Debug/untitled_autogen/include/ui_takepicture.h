/********************************************************************************
** Form generated from reading UI file 'takepicture.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TAKEPICTURE_H
#define UI_TAKEPICTURE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_takepicture
{
public:
    QLabel *label;
    QLabel *lblPOBTP;
    QLabel *lblNameTP;
    QLabel *lblSexTP;
    QLabel *lblDOBTP;
    QLineEdit *txteNameTP;
    QLineEdit *txteSexTP;
    QLineEdit *txteDOBTP;
    QLineEdit *txtePOBTP;
    QPushButton *btnBackTP;
    QPushButton *btnOpenCameraTP;

    void setupUi(QWidget *takepicture)
    {
        if (takepicture->objectName().isEmpty())
            takepicture->setObjectName(QString::fromUtf8("takepicture"));
        takepicture->resize(800, 600);
        label = new QLabel(takepicture);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(260, 20, 291, 71));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        lblPOBTP = new QLabel(takepicture);
        lblPOBTP->setObjectName(QString::fromUtf8("lblPOBTP"));
        lblPOBTP->setGeometry(QRect(210, 350, 61, 31));
        lblNameTP = new QLabel(takepicture);
        lblNameTP->setObjectName(QString::fromUtf8("lblNameTP"));
        lblNameTP->setGeometry(QRect(210, 170, 101, 31));
        lblSexTP = new QLabel(takepicture);
        lblSexTP->setObjectName(QString::fromUtf8("lblSexTP"));
        lblSexTP->setGeometry(QRect(210, 230, 101, 31));
        lblDOBTP = new QLabel(takepicture);
        lblDOBTP->setObjectName(QString::fromUtf8("lblDOBTP"));
        lblDOBTP->setGeometry(QRect(210, 290, 101, 31));
        txteNameTP = new QLineEdit(takepicture);
        txteNameTP->setObjectName(QString::fromUtf8("txteNameTP"));
        txteNameTP->setGeometry(QRect(290, 170, 271, 31));
        txteSexTP = new QLineEdit(takepicture);
        txteSexTP->setObjectName(QString::fromUtf8("txteSexTP"));
        txteSexTP->setGeometry(QRect(290, 230, 271, 31));
        txteDOBTP = new QLineEdit(takepicture);
        txteDOBTP->setObjectName(QString::fromUtf8("txteDOBTP"));
        txteDOBTP->setGeometry(QRect(290, 290, 271, 31));
        txtePOBTP = new QLineEdit(takepicture);
        txtePOBTP->setObjectName(QString::fromUtf8("txtePOBTP"));
        txtePOBTP->setGeometry(QRect(290, 350, 271, 31));
        btnBackTP = new QPushButton(takepicture);
        btnBackTP->setObjectName(QString::fromUtf8("btnBackTP"));
        btnBackTP->setGeometry(QRect(280, 490, 101, 31));
        btnOpenCameraTP = new QPushButton(takepicture);
        btnOpenCameraTP->setObjectName(QString::fromUtf8("btnOpenCameraTP"));
        btnOpenCameraTP->setGeometry(QRect(420, 490, 101, 31));

        retranslateUi(takepicture);

        QMetaObject::connectSlotsByName(takepicture);
    } // setupUi

    void retranslateUi(QWidget *takepicture)
    {
        takepicture->setWindowTitle(QCoreApplication::translate("takepicture", "Form", nullptr));
        label->setText(QCoreApplication::translate("takepicture", "Take picture", nullptr));
        lblPOBTP->setText(QCoreApplication::translate("takepicture", "POB", nullptr));
        lblNameTP->setText(QCoreApplication::translate("takepicture", "Name", nullptr));
        lblSexTP->setText(QCoreApplication::translate("takepicture", "Sex", nullptr));
        lblDOBTP->setText(QCoreApplication::translate("takepicture", "DOB", nullptr));
        btnBackTP->setText(QCoreApplication::translate("takepicture", "Back", nullptr));
        btnOpenCameraTP->setText(QCoreApplication::translate("takepicture", "Open camera", nullptr));
    } // retranslateUi

};

namespace Ui {
    class takepicture: public Ui_takepicture {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TAKEPICTURE_H
