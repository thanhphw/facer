/********************************************************************************
** Form generated from reading UI file 'managedata.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGEDATA_H
#define UI_MANAGEDATA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_managedata
{
public:
    QLabel *label;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QCheckBox *checkBox_4;
    QLabel *lblSTT1;
    QLabel *lblSTT2;
    QLabel *lblSTT3;
    QLabel *lblSTT4;
    QLabel *lblName1;
    QLabel *lblName2;
    QLabel *lblName3;
    QLabel *lblName4;
    QPushButton *BtnBackManage;
    QPushButton *BtnDeleteMana;
    QPushButton *BtnModifyMana;

    void setupUi(QWidget *managedata)
    {
        if (managedata->objectName().isEmpty())
            managedata->setObjectName(QString::fromUtf8("managedata"));
        managedata->resize(800, 600);
        label = new QLabel(managedata);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(270, 50, 251, 71));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        checkBox = new QCheckBox(managedata);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(160, 190, 31, 28));
        checkBox_2 = new QCheckBox(managedata);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(160, 240, 31, 28));
        checkBox_3 = new QCheckBox(managedata);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(160, 290, 31, 28));
        checkBox_4 = new QCheckBox(managedata);
        checkBox_4->setObjectName(QString::fromUtf8("checkBox_4"));
        checkBox_4->setGeometry(QRect(160, 340, 31, 28));
        lblSTT1 = new QLabel(managedata);
        lblSTT1->setObjectName(QString::fromUtf8("lblSTT1"));
        lblSTT1->setGeometry(QRect(280, 190, 31, 31));
        lblSTT2 = new QLabel(managedata);
        lblSTT2->setObjectName(QString::fromUtf8("lblSTT2"));
        lblSTT2->setGeometry(QRect(280, 240, 31, 31));
        lblSTT3 = new QLabel(managedata);
        lblSTT3->setObjectName(QString::fromUtf8("lblSTT3"));
        lblSTT3->setGeometry(QRect(280, 290, 31, 31));
        lblSTT4 = new QLabel(managedata);
        lblSTT4->setObjectName(QString::fromUtf8("lblSTT4"));
        lblSTT4->setGeometry(QRect(280, 340, 31, 31));
        lblName1 = new QLabel(managedata);
        lblName1->setObjectName(QString::fromUtf8("lblName1"));
        lblName1->setGeometry(QRect(420, 190, 261, 31));
        lblName2 = new QLabel(managedata);
        lblName2->setObjectName(QString::fromUtf8("lblName2"));
        lblName2->setGeometry(QRect(420, 240, 261, 31));
        lblName3 = new QLabel(managedata);
        lblName3->setObjectName(QString::fromUtf8("lblName3"));
        lblName3->setGeometry(QRect(420, 290, 261, 31));
        lblName4 = new QLabel(managedata);
        lblName4->setObjectName(QString::fromUtf8("lblName4"));
        lblName4->setGeometry(QRect(420, 340, 261, 31));
        BtnBackManage = new QPushButton(managedata);
        BtnBackManage->setObjectName(QString::fromUtf8("BtnBackManage"));
        BtnBackManage->setGeometry(QRect(180, 460, 91, 30));
        BtnDeleteMana = new QPushButton(managedata);
        BtnDeleteMana->setObjectName(QString::fromUtf8("BtnDeleteMana"));
        BtnDeleteMana->setGeometry(QRect(360, 460, 91, 30));
        BtnModifyMana = new QPushButton(managedata);
        BtnModifyMana->setObjectName(QString::fromUtf8("BtnModifyMana"));
        BtnModifyMana->setGeometry(QRect(530, 460, 91, 30));

        retranslateUi(managedata);

        QMetaObject::connectSlotsByName(managedata);
    } // setupUi

    void retranslateUi(QWidget *managedata)
    {
        managedata->setWindowTitle(QCoreApplication::translate("managedata", "Form", nullptr));
        label->setText(QCoreApplication::translate("managedata", "Manage data", nullptr));
        checkBox->setText(QString());
        checkBox_2->setText(QString());
        checkBox_3->setText(QString());
        checkBox_4->setText(QString());
        lblSTT1->setText(QCoreApplication::translate("managedata", "1", nullptr));
        lblSTT2->setText(QCoreApplication::translate("managedata", "2", nullptr));
        lblSTT3->setText(QCoreApplication::translate("managedata", "3", nullptr));
        lblSTT4->setText(QCoreApplication::translate("managedata", "4", nullptr));
        lblName1->setText(QCoreApplication::translate("managedata", "Truong Thanh Phuong", nullptr));
        lblName2->setText(QCoreApplication::translate("managedata", "Pham Vu Hop", nullptr));
        lblName3->setText(QCoreApplication::translate("managedata", "Tran Van Hoang", nullptr));
        lblName4->setText(QCoreApplication::translate("managedata", "Le Viet Xuan", nullptr));
        BtnBackManage->setText(QCoreApplication::translate("managedata", "Back", nullptr));
        BtnDeleteMana->setText(QCoreApplication::translate("managedata", "Delete", nullptr));
        BtnModifyMana->setText(QCoreApplication::translate("managedata", "Modify", nullptr));
    } // retranslateUi

};

namespace Ui {
    class managedata: public Ui_managedata {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGEDATA_H
