/********************************************************************************
** Form generated from reading UI file 'facerecog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FACERECOG_H
#define UI_FACERECOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_facerecog
{
public:
    QLabel *label;
    QGroupBox *groupBox_FaceRecog;
    QPushButton *BtnTakePicture;
    QPushButton *BtnTrainModel;
    QPushButton *BtnBackFaceR;
    QPushButton *BtnOpenCamera;

    void setupUi(QWidget *facerecog)
    {
        if (facerecog->objectName().isEmpty())
            facerecog->setObjectName(QString::fromUtf8("facerecog"));
        facerecog->resize(800, 600);
        label = new QLabel(facerecog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(240, 30, 301, 91));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        groupBox_FaceRecog = new QGroupBox(facerecog);
        groupBox_FaceRecog->setObjectName(QString::fromUtf8("groupBox_FaceRecog"));
        groupBox_FaceRecog->setGeometry(QRect(200, 180, 361, 341));
        BtnTakePicture = new QPushButton(groupBox_FaceRecog);
        BtnTakePicture->setObjectName(QString::fromUtf8("BtnTakePicture"));
        BtnTakePicture->setGeometry(QRect(50, 30, 261, 41));
        BtnTrainModel = new QPushButton(groupBox_FaceRecog);
        BtnTrainModel->setObjectName(QString::fromUtf8("BtnTrainModel"));
        BtnTrainModel->setGeometry(QRect(50, 110, 261, 41));
        BtnBackFaceR = new QPushButton(groupBox_FaceRecog);
        BtnBackFaceR->setObjectName(QString::fromUtf8("BtnBackFaceR"));
        BtnBackFaceR->setGeometry(QRect(50, 270, 261, 41));
        BtnOpenCamera = new QPushButton(groupBox_FaceRecog);
        BtnOpenCamera->setObjectName(QString::fromUtf8("BtnOpenCamera"));
        BtnOpenCamera->setGeometry(QRect(50, 190, 261, 41));

        retranslateUi(facerecog);

        QMetaObject::connectSlotsByName(facerecog);
    } // setupUi

    void retranslateUi(QWidget *facerecog)
    {
        facerecog->setWindowTitle(QCoreApplication::translate("facerecog", "Form", nullptr));
        label->setText(QCoreApplication::translate("facerecog", "Face recognition", nullptr));
        groupBox_FaceRecog->setTitle(QString());
        BtnTakePicture->setText(QCoreApplication::translate("facerecog", "Take picture", nullptr));
        BtnTrainModel->setText(QCoreApplication::translate("facerecog", "Train model", nullptr));
        BtnBackFaceR->setText(QCoreApplication::translate("facerecog", "Back", nullptr));
        BtnOpenCamera->setText(QCoreApplication::translate("facerecog", "Open camera to recognize", nullptr));
    } // retranslateUi

};

namespace Ui {
    class facerecog: public Ui_facerecog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FACERECOG_H
