/********************************************************************************
** Form generated from reading UI file 'selectfacerecog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SELECTFACERECOG_H
#define UI_SELECTFACERECOG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_selectfacerecog
{
public:
    QLabel *label;
    QGroupBox *groupBox_selectFaceR;
    QPushButton *BtnNeuralNetworkSFR;
    QPushButton *BtnLBPHSFR;
    QPushButton *BtnBackSFR;

    void setupUi(QWidget *selectfacerecog)
    {
        if (selectfacerecog->objectName().isEmpty())
            selectfacerecog->setObjectName(QString::fromUtf8("selectfacerecog"));
        selectfacerecog->resize(800, 600);
        label = new QLabel(selectfacerecog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(180, 30, 421, 101));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        groupBox_selectFaceR = new QGroupBox(selectfacerecog);
        groupBox_selectFaceR->setObjectName(QString::fromUtf8("groupBox_selectFaceR"));
        groupBox_selectFaceR->setGeometry(QRect(200, 200, 361, 261));
        BtnNeuralNetworkSFR = new QPushButton(groupBox_selectFaceR);
        BtnNeuralNetworkSFR->setObjectName(QString::fromUtf8("BtnNeuralNetworkSFR"));
        BtnNeuralNetworkSFR->setGeometry(QRect(50, 30, 261, 41));
        BtnLBPHSFR = new QPushButton(groupBox_selectFaceR);
        BtnLBPHSFR->setObjectName(QString::fromUtf8("BtnLBPHSFR"));
        BtnLBPHSFR->setGeometry(QRect(50, 110, 261, 41));
        BtnBackSFR = new QPushButton(groupBox_selectFaceR);
        BtnBackSFR->setObjectName(QString::fromUtf8("BtnBackSFR"));
        BtnBackSFR->setGeometry(QRect(50, 190, 261, 41));

        retranslateUi(selectfacerecog);

        QMetaObject::connectSlotsByName(selectfacerecog);
    } // setupUi

    void retranslateUi(QWidget *selectfacerecog)
    {
        selectfacerecog->setWindowTitle(QCoreApplication::translate("selectfacerecog", "Form", nullptr));
        label->setText(QCoreApplication::translate("selectfacerecog", "Select Face Reconiged", nullptr));
        groupBox_selectFaceR->setTitle(QString());
        BtnNeuralNetworkSFR->setText(QCoreApplication::translate("selectfacerecog", "Neural network", nullptr));
        BtnLBPHSFR->setText(QCoreApplication::translate("selectfacerecog", "LBPH", nullptr));
        BtnBackSFR->setText(QCoreApplication::translate("selectfacerecog", "Back", nullptr));
    } // retranslateUi

};

namespace Ui {
    class selectfacerecog: public Ui_selectfacerecog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SELECTFACERECOG_H
