/********************************************************************************
** Form generated from reading UI file 'homescreen.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOMESCREEN_H
#define UI_HOMESCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_homescreen
{
public:
    QLabel *lblTitleHome1;
    QLabel *lblTitleHome2;
    QGroupBox *groupBox_Home;
    QPushButton *BtnFaceRecog;
    QPushButton *BtnHistory;
    QPushButton *BtnAccountInfo;
    QPushButton *BtnManageData;

    void setupUi(QDialog *homescreen)
    {
        if (homescreen->objectName().isEmpty())
            homescreen->setObjectName(QString::fromUtf8("homescreen"));
        homescreen->resize(800, 600);
        lblTitleHome1 = new QLabel(homescreen);
        lblTitleHome1->setObjectName(QString::fromUtf8("lblTitleHome1"));
        lblTitleHome1->setGeometry(QRect(130, 20, 561, 61));
        QFont font;
        font.setPointSize(30);
        lblTitleHome1->setFont(font);
        lblTitleHome1->setFrameShadow(QFrame::Sunken);
        lblTitleHome2 = new QLabel(homescreen);
        lblTitleHome2->setObjectName(QString::fromUtf8("lblTitleHome2"));
        lblTitleHome2->setGeometry(QRect(270, 90, 241, 51));
        QFont font1;
        font1.setPointSize(15);
        lblTitleHome2->setFont(font1);
        lblTitleHome2->setFrameShadow(QFrame::Sunken);
        groupBox_Home = new QGroupBox(homescreen);
        groupBox_Home->setObjectName(QString::fromUtf8("groupBox_Home"));
        groupBox_Home->setGeometry(QRect(200, 180, 361, 341));
        BtnFaceRecog = new QPushButton(groupBox_Home);
        BtnFaceRecog->setObjectName(QString::fromUtf8("BtnFaceRecog"));
        BtnFaceRecog->setGeometry(QRect(50, 30, 261, 41));
        BtnHistory = new QPushButton(groupBox_Home);
        BtnHistory->setObjectName(QString::fromUtf8("BtnHistory"));
        BtnHistory->setGeometry(QRect(50, 110, 261, 41));
        BtnAccountInfo = new QPushButton(groupBox_Home);
        BtnAccountInfo->setObjectName(QString::fromUtf8("BtnAccountInfo"));
        BtnAccountInfo->setGeometry(QRect(50, 270, 261, 41));
        BtnManageData = new QPushButton(groupBox_Home);
        BtnManageData->setObjectName(QString::fromUtf8("BtnManageData"));
        BtnManageData->setGeometry(QRect(50, 190, 261, 41));

        retranslateUi(homescreen);

        QMetaObject::connectSlotsByName(homescreen);
    } // setupUi

    void retranslateUi(QDialog *homescreen)
    {
        homescreen->setWindowTitle(QCoreApplication::translate("homescreen", "Dialog", nullptr));
        lblTitleHome1->setText(QCoreApplication::translate("homescreen", "FACE RECOGNITION SYSTEM", nullptr));
        lblTitleHome2->setText(QCoreApplication::translate("homescreen", "Khoa luan tot nghiep 2023", nullptr));
        groupBox_Home->setTitle(QString());
        BtnFaceRecog->setText(QCoreApplication::translate("homescreen", "Face recognition", nullptr));
        BtnHistory->setText(QCoreApplication::translate("homescreen", "History", nullptr));
        BtnAccountInfo->setText(QCoreApplication::translate("homescreen", "Account information", nullptr));
        BtnManageData->setText(QCoreApplication::translate("homescreen", "Manage data", nullptr));
    } // retranslateUi

};

namespace Ui {
    class homescreen: public Ui_homescreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOMESCREEN_H
