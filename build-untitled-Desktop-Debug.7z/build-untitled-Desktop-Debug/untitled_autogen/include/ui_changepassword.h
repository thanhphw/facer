/********************************************************************************
** Form generated from reading UI file 'changepassword.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CHANGEPASSWORD_H
#define UI_CHANGEPASSWORD_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_changepassword
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QPushButton *btnBack;
    QPushButton *btnConf;
    QLineEdit *txteOldPass;
    QLineEdit *txteNewPass;
    QLineEdit *txteConfPass;

    void setupUi(QWidget *changepassword)
    {
        if (changepassword->objectName().isEmpty())
            changepassword->setObjectName(QString::fromUtf8("changepassword"));
        changepassword->resize(800, 600);
        label = new QLabel(changepassword);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(240, 20, 321, 101));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        label_2 = new QLabel(changepassword);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(100, 190, 141, 31));
        label_3 = new QLabel(changepassword);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(100, 260, 141, 31));
        label_4 = new QLabel(changepassword);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(100, 330, 141, 31));
        btnBack = new QPushButton(changepassword);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setGeometry(QRect(280, 440, 91, 30));
        btnConf = new QPushButton(changepassword);
        btnConf->setObjectName(QString::fromUtf8("btnConf"));
        btnConf->setGeometry(QRect(420, 440, 91, 30));
        txteOldPass = new QLineEdit(changepassword);
        txteOldPass->setObjectName(QString::fromUtf8("txteOldPass"));
        txteOldPass->setGeometry(QRect(290, 190, 351, 31));
        txteNewPass = new QLineEdit(changepassword);
        txteNewPass->setObjectName(QString::fromUtf8("txteNewPass"));
        txteNewPass->setGeometry(QRect(290, 250, 351, 31));
        txteConfPass = new QLineEdit(changepassword);
        txteConfPass->setObjectName(QString::fromUtf8("txteConfPass"));
        txteConfPass->setGeometry(QRect(290, 320, 351, 31));

        retranslateUi(changepassword);

        QMetaObject::connectSlotsByName(changepassword);
    } // setupUi

    void retranslateUi(QWidget *changepassword)
    {
        changepassword->setWindowTitle(QCoreApplication::translate("changepassword", "Form", nullptr));
        label->setText(QCoreApplication::translate("changepassword", "Change password", nullptr));
        label_2->setText(QCoreApplication::translate("changepassword", "Old password", nullptr));
        label_3->setText(QCoreApplication::translate("changepassword", "New password", nullptr));
        label_4->setText(QCoreApplication::translate("changepassword", "Confirm password", nullptr));
        btnBack->setText(QCoreApplication::translate("changepassword", "Back", nullptr));
        btnConf->setText(QCoreApplication::translate("changepassword", "Confirm", nullptr));
    } // retranslateUi

};

namespace Ui {
    class changepassword: public Ui_changepassword {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CHANGEPASSWORD_H
