/********************************************************************************
** Form generated from reading UI file 'accountinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNTINFO_H
#define UI_ACCOUNTINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_accountinfo
{
public:
    QLabel *lblFullName;
    QGroupBox *groupBox_Account;
    QPushButton *BtnChangePass;
    QPushButton *BtnChangeInfo;
    QPushButton *BtnBackAccountInfo;
    QPushButton *BtnLogout;
    QLabel *lblStatus;

    void setupUi(QDialog *accountinfo)
    {
        if (accountinfo->objectName().isEmpty())
            accountinfo->setObjectName(QString::fromUtf8("accountinfo"));
        accountinfo->resize(800, 600);
        lblFullName = new QLabel(accountinfo);
        lblFullName->setObjectName(QString::fromUtf8("lblFullName"));
        lblFullName->setGeometry(QRect(240, 10, 491, 71));
        QFont font;
        font.setPointSize(30);
        lblFullName->setFont(font);
        groupBox_Account = new QGroupBox(accountinfo);
        groupBox_Account->setObjectName(QString::fromUtf8("groupBox_Account"));
        groupBox_Account->setGeometry(QRect(200, 180, 361, 341));
        BtnChangePass = new QPushButton(groupBox_Account);
        BtnChangePass->setObjectName(QString::fromUtf8("BtnChangePass"));
        BtnChangePass->setGeometry(QRect(50, 30, 261, 41));
        BtnChangeInfo = new QPushButton(groupBox_Account);
        BtnChangeInfo->setObjectName(QString::fromUtf8("BtnChangeInfo"));
        BtnChangeInfo->setGeometry(QRect(50, 110, 261, 41));
        BtnBackAccountInfo = new QPushButton(groupBox_Account);
        BtnBackAccountInfo->setObjectName(QString::fromUtf8("BtnBackAccountInfo"));
        BtnBackAccountInfo->setGeometry(QRect(50, 270, 261, 41));
        BtnLogout = new QPushButton(groupBox_Account);
        BtnLogout->setObjectName(QString::fromUtf8("BtnLogout"));
        BtnLogout->setGeometry(QRect(50, 190, 261, 41));
        lblStatus = new QLabel(accountinfo);
        lblStatus->setObjectName(QString::fromUtf8("lblStatus"));
        lblStatus->setGeometry(QRect(240, 90, 551, 41));
        QFont font1;
        font1.setPointSize(15);
        font1.setItalic(true);
        lblStatus->setFont(font1);

        retranslateUi(accountinfo);

        QMetaObject::connectSlotsByName(accountinfo);
    } // setupUi

    void retranslateUi(QDialog *accountinfo)
    {
        accountinfo->setWindowTitle(QCoreApplication::translate("accountinfo", "Dialog", nullptr));
        lblFullName->setText(QCoreApplication::translate("accountinfo", "Pham Vu Hop", nullptr));
        groupBox_Account->setTitle(QString());
        BtnChangePass->setText(QCoreApplication::translate("accountinfo", "Change password", nullptr));
        BtnChangeInfo->setText(QCoreApplication::translate("accountinfo", "Change information", nullptr));
        BtnBackAccountInfo->setText(QCoreApplication::translate("accountinfo", "Back", nullptr));
        BtnLogout->setText(QCoreApplication::translate("accountinfo", "Log out", nullptr));
        lblStatus->setText(QCoreApplication::translate("accountinfo", "Animal is everything with me, to be continued...", nullptr));
    } // retranslateUi

};

namespace Ui {
    class accountinfo: public Ui_accountinfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNTINFO_H
