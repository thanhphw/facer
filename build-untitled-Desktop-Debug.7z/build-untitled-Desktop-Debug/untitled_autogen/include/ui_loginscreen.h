/********************************************************************************
** Form generated from reading UI file 'loginscreen.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGINSCREEN_H
#define UI_LOGINSCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_loginscreen
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QPushButton *BtnOkLogin;
    QPushButton *BtnCancelLogin;
    QLineEdit *TxteID;
    QLineEdit *TxtePass;
    QLabel *lblCapsLockNotif;
    QPushButton *BtnRegisterLogin;
    QLineEdit *TxtePassConf;
    QLabel *lblConfPass;
    QPushButton *BtnOkRegistor;
    QPushButton *BtnCancelRegistor;
    QLabel *lblHaveAcc;

    void setupUi(QDialog *loginscreen)
    {
        if (loginscreen->objectName().isEmpty())
            loginscreen->setObjectName(QString::fromUtf8("loginscreen"));
        loginscreen->resize(498, 385);
        label = new QLabel(loginscreen);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(240, 20, 68, 31));
        QFont font;
        font.setPointSize(16);
        label->setFont(font);
        label_2 = new QLabel(loginscreen);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 120, 68, 22));
        label_3 = new QLabel(loginscreen);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(50, 160, 71, 22));
        BtnOkLogin = new QPushButton(loginscreen);
        BtnOkLogin->setObjectName(QString::fromUtf8("BtnOkLogin"));
        BtnOkLogin->setGeometry(QRect(160, 220, 101, 30));
        BtnCancelLogin = new QPushButton(loginscreen);
        BtnCancelLogin->setObjectName(QString::fromUtf8("BtnCancelLogin"));
        BtnCancelLogin->setGeometry(QRect(280, 220, 101, 30));
        TxteID = new QLineEdit(loginscreen);
        TxteID->setObjectName(QString::fromUtf8("TxteID"));
        TxteID->setGeometry(QRect(160, 110, 221, 31));
        TxtePass = new QLineEdit(loginscreen);
        TxtePass->setObjectName(QString::fromUtf8("TxtePass"));
        TxtePass->setGeometry(QRect(160, 160, 221, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Noto Serif Ethiopic Md"));
        font1.setPointSize(10);
        TxtePass->setFont(font1);
        lblCapsLockNotif = new QLabel(loginscreen);
        lblCapsLockNotif->setObjectName(QString::fromUtf8("lblCapsLockNotif"));
        lblCapsLockNotif->setGeometry(QRect(220, 350, 101, 31));
        QFont font2;
        font2.setPointSize(10);
        lblCapsLockNotif->setFont(font2);
        BtnRegisterLogin = new QPushButton(loginscreen);
        BtnRegisterLogin->setObjectName(QString::fromUtf8("BtnRegisterLogin"));
        BtnRegisterLogin->setGeometry(QRect(220, 290, 101, 30));
        TxtePassConf = new QLineEdit(loginscreen);
        TxtePassConf->setObjectName(QString::fromUtf8("TxtePassConf"));
        TxtePassConf->setGeometry(QRect(160, 210, 221, 31));
        TxtePassConf->setFont(font1);
        lblConfPass = new QLabel(loginscreen);
        lblConfPass->setObjectName(QString::fromUtf8("lblConfPass"));
        lblConfPass->setGeometry(QRect(50, 210, 101, 21));
        BtnOkRegistor = new QPushButton(loginscreen);
        BtnOkRegistor->setObjectName(QString::fromUtf8("BtnOkRegistor"));
        BtnOkRegistor->setGeometry(QRect(160, 260, 101, 30));
        BtnCancelRegistor = new QPushButton(loginscreen);
        BtnCancelRegistor->setObjectName(QString::fromUtf8("BtnCancelRegistor"));
        BtnCancelRegistor->setGeometry(QRect(280, 260, 101, 30));
        lblHaveAcc = new QLabel(loginscreen);
        lblHaveAcc->setObjectName(QString::fromUtf8("lblHaveAcc"));
        lblHaveAcc->setGeometry(QRect(200, 260, 161, 21));
        QFont font3;
        font3.setPointSize(11);
        lblHaveAcc->setFont(font3);

        retranslateUi(loginscreen);

        QMetaObject::connectSlotsByName(loginscreen);
    } // setupUi

    void retranslateUi(QDialog *loginscreen)
    {
        loginscreen->setWindowTitle(QCoreApplication::translate("loginscreen", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("loginscreen", "Login", nullptr));
        label_2->setText(QCoreApplication::translate("loginscreen", "ID", nullptr));
        label_3->setText(QCoreApplication::translate("loginscreen", "Password", nullptr));
        BtnOkLogin->setText(QCoreApplication::translate("loginscreen", "Login", nullptr));
        BtnCancelLogin->setText(QCoreApplication::translate("loginscreen", "Cancel", nullptr));
        TxteID->setText(QString());
        TxtePass->setText(QString());
        lblCapsLockNotif->setText(QCoreApplication::translate("loginscreen", "Caps Lock is ON", nullptr));
        BtnRegisterLogin->setText(QCoreApplication::translate("loginscreen", "Register", nullptr));
#if QT_CONFIG(shortcut)
        BtnRegisterLogin->setShortcut(QString());
#endif // QT_CONFIG(shortcut)
        TxtePassConf->setText(QString());
        lblConfPass->setText(QCoreApplication::translate("loginscreen", "Confirm Pass", nullptr));
        BtnOkRegistor->setText(QCoreApplication::translate("loginscreen", "Sign up", nullptr));
        BtnCancelRegistor->setText(QCoreApplication::translate("loginscreen", "Back", nullptr));
        lblHaveAcc->setText(QCoreApplication::translate("loginscreen", "Don't have an account", nullptr));
    } // retranslateUi

};

namespace Ui {
    class loginscreen: public Ui_loginscreen {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGINSCREEN_H
