/********************************************************************************
** Form generated from reading UI file 'login_screen.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGIN_SCREEN_H
#define UI_LOGIN_SCREEN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_Dialog
{
public:
    QLabel *label;
    QLabel *label_2;
    QTextEdit *TxteID;
    QTextEdit *TxtePassword;
    QLabel *label_3;
    QPushButton *BtnOkLogin;
    QPushButton *BtnCancelLogin;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(400, 300);
        label = new QLabel(Dialog);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(20, 90, 101, 31));
        label_2 = new QLabel(Dialog);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 140, 101, 31));
        TxteID = new QTextEdit(Dialog);
        TxteID->setObjectName(QString::fromUtf8("TxteID"));
        TxteID->setGeometry(QRect(140, 80, 231, 41));
        TxtePassword = new QTextEdit(Dialog);
        TxtePassword->setObjectName(QString::fromUtf8("TxtePassword"));
        TxtePassword->setGeometry(QRect(140, 140, 231, 41));
        label_3 = new QLabel(Dialog);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(150, 10, 101, 31));
        QFont font;
        font.setPointSize(16);
        label_3->setFont(font);
        BtnOkLogin = new QPushButton(Dialog);
        BtnOkLogin->setObjectName(QString::fromUtf8("BtnOkLogin"));
        BtnOkLogin->setGeometry(QRect(140, 200, 101, 30));
        BtnCancelLogin = new QPushButton(Dialog);
        BtnCancelLogin->setObjectName(QString::fromUtf8("BtnCancelLogin"));
        BtnCancelLogin->setGeometry(QRect(270, 200, 101, 30));

        retranslateUi(Dialog);

        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QCoreApplication::translate("Dialog", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("Dialog", "ID", nullptr));
        label_2->setText(QCoreApplication::translate("Dialog", "Password", nullptr));
        label_3->setText(QCoreApplication::translate("Dialog", "Login", nullptr));
        BtnOkLogin->setText(QCoreApplication::translate("Dialog", "Login", nullptr));
        BtnCancelLogin->setText(QCoreApplication::translate("Dialog", "Cancel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Dialog: public Ui_Dialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGIN_SCREEN_H
