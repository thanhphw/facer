/********************************************************************************
** Form generated from reading UI file 'personalinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PERSONALINFO_H
#define UI_PERSONALINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_PersonalInfo
{
public:
    QLabel *label;
    QLabel *lblNamePI;
    QLabel *lblDOBPI;
    QLabel *lblSexPI;
    QLabel *lblPOBPI;
    QLineEdit *txteNamePI;
    QLineEdit *txteSexPI;
    QLineEdit *txteDOBPI;
    QLineEdit *txtePOBPI;
    QPushButton *btnBackPI;
    QPushButton *BtnBefPI;
    QPushButton *BtnAftPI;
    QLabel *lblIndexImagePI;

    void setupUi(QWidget *PersonalInfo)
    {
        if (PersonalInfo->objectName().isEmpty())
            PersonalInfo->setObjectName(QString::fromUtf8("PersonalInfo"));
        PersonalInfo->resize(800, 600);
        label = new QLabel(PersonalInfo);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(190, 30, 421, 91));
        QFont font;
        font.setPointSize(30);
        label->setFont(font);
        lblNamePI = new QLabel(PersonalInfo);
        lblNamePI->setObjectName(QString::fromUtf8("lblNamePI"));
        lblNamePI->setGeometry(QRect(80, 210, 101, 31));
        lblDOBPI = new QLabel(PersonalInfo);
        lblDOBPI->setObjectName(QString::fromUtf8("lblDOBPI"));
        lblDOBPI->setGeometry(QRect(80, 330, 101, 31));
        lblSexPI = new QLabel(PersonalInfo);
        lblSexPI->setObjectName(QString::fromUtf8("lblSexPI"));
        lblSexPI->setGeometry(QRect(80, 270, 101, 31));
        lblPOBPI = new QLabel(PersonalInfo);
        lblPOBPI->setObjectName(QString::fromUtf8("lblPOBPI"));
        lblPOBPI->setGeometry(QRect(80, 390, 61, 31));
        txteNamePI = new QLineEdit(PersonalInfo);
        txteNamePI->setObjectName(QString::fromUtf8("txteNamePI"));
        txteNamePI->setGeometry(QRect(160, 210, 271, 31));
        txteSexPI = new QLineEdit(PersonalInfo);
        txteSexPI->setObjectName(QString::fromUtf8("txteSexPI"));
        txteSexPI->setGeometry(QRect(160, 270, 271, 31));
        txteDOBPI = new QLineEdit(PersonalInfo);
        txteDOBPI->setObjectName(QString::fromUtf8("txteDOBPI"));
        txteDOBPI->setGeometry(QRect(160, 330, 271, 31));
        txtePOBPI = new QLineEdit(PersonalInfo);
        txtePOBPI->setObjectName(QString::fromUtf8("txtePOBPI"));
        txtePOBPI->setGeometry(QRect(160, 390, 271, 31));
        btnBackPI = new QPushButton(PersonalInfo);
        btnBackPI->setObjectName(QString::fromUtf8("btnBackPI"));
        btnBackPI->setGeometry(QRect(350, 540, 91, 30));
        BtnBefPI = new QPushButton(PersonalInfo);
        BtnBefPI->setObjectName(QString::fromUtf8("BtnBefPI"));
        BtnBefPI->setGeometry(QRect(540, 460, 31, 31));
        BtnAftPI = new QPushButton(PersonalInfo);
        BtnAftPI->setObjectName(QString::fromUtf8("BtnAftPI"));
        BtnAftPI->setGeometry(QRect(680, 460, 31, 31));
        lblIndexImagePI = new QLabel(PersonalInfo);
        lblIndexImagePI->setObjectName(QString::fromUtf8("lblIndexImagePI"));
        lblIndexImagePI->setGeometry(QRect(610, 460, 51, 31));

        retranslateUi(PersonalInfo);

        QMetaObject::connectSlotsByName(PersonalInfo);
    } // setupUi

    void retranslateUi(QWidget *PersonalInfo)
    {
        PersonalInfo->setWindowTitle(QCoreApplication::translate("PersonalInfo", "Form", nullptr));
        label->setText(QCoreApplication::translate("PersonalInfo", "Personal information", nullptr));
        lblNamePI->setText(QCoreApplication::translate("PersonalInfo", "Name", nullptr));
        lblDOBPI->setText(QCoreApplication::translate("PersonalInfo", "DOB", nullptr));
        lblSexPI->setText(QCoreApplication::translate("PersonalInfo", "Sex", nullptr));
        lblPOBPI->setText(QCoreApplication::translate("PersonalInfo", "POB", nullptr));
        btnBackPI->setText(QCoreApplication::translate("PersonalInfo", "Back", nullptr));
        BtnBefPI->setText(QCoreApplication::translate("PersonalInfo", "<", nullptr));
        BtnAftPI->setText(QCoreApplication::translate("PersonalInfo", ">", nullptr));
        lblIndexImagePI->setText(QCoreApplication::translate("PersonalInfo", "5/12", nullptr));
    } // retranslateUi

};

namespace Ui {
    class PersonalInfo: public Ui_PersonalInfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PERSONALINFO_H
