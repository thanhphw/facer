/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QPushButton *BtnFaceShot;
    QPushButton *BtnTrainModel;
    QPushButton *BtnFaceRec;
    QTextEdit *TxteInputName;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(800, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        BtnFaceShot = new QPushButton(centralwidget);
        BtnFaceShot->setObjectName(QString::fromUtf8("BtnFaceShot"));
        BtnFaceShot->setGeometry(QRect(180, 440, 111, 31));
        BtnTrainModel = new QPushButton(centralwidget);
        BtnTrainModel->setObjectName(QString::fromUtf8("BtnTrainModel"));
        BtnTrainModel->setGeometry(QRect(310, 440, 111, 31));
        BtnFaceRec = new QPushButton(centralwidget);
        BtnFaceRec->setObjectName(QString::fromUtf8("BtnFaceRec"));
        BtnFaceRec->setGeometry(QRect(440, 440, 121, 31));
        TxteInputName = new QTextEdit(centralwidget);
        TxteInputName->setObjectName(QString::fromUtf8("TxteInputName"));
        TxteInputName->setGeometry(QRect(160, 370, 431, 51));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 27));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        BtnFaceShot->setText(QCoreApplication::translate("MainWindow", "Face shot", nullptr));
        BtnTrainModel->setText(QCoreApplication::translate("MainWindow", "Train model", nullptr));
        BtnFaceRec->setText(QCoreApplication::translate("MainWindow", "Face recognition", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
