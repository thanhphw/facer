import cv2
import socketserver

class MyTCPHandler(socketserver.BaseRequestHandler):
    def handle(self):
        
        
        data = self.request.recv(1024).strip()

        name = data.decode()
        print("Received data:", name)
        # Your existing code to capture and save images with the received name
        cam = cv2.VideoCapture(0)
        data1 = ''
        cv2.namedWindow("Set for " + name, cv2.WINDOW_NORMAL)
        cv2.resizeWindow("Set for " + name, 500, 300)

        img_counter = 0

        while True:
            ret, frame = cam.read()
            if not ret:
                print("Failed to grab frame")
                break
            cv2.imshow("Set for " + name, frame)

            k = cv2.waitKey(1)
            if k%256 == 27:
                print("Escape hit, closing..")
                break
            elif k%256 == 32:
                img_name = "dataset/{}/image_{}.jpg".format(name, img_counter)
                cv2.imwrite(img_name, frame)
                print("{} written!".format(img_name))
                img_counter += 1

        cam.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    HOST, PORT = "localhost", 1235
    server = socketserver.TCPServer((HOST, PORT), MyTCPHandler)
    server.serve_forever()