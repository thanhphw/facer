#include <opencv2/opencv.hpp>
#include <opencv2/face.hpp>
#include <iostream>
#include <map>  // Include the map header
#include <sys/socket.h>
#include <arpa/inet.h>
using namespace cv;

void receiveStringFromSocket(int nSocket, std::string& receivedString) {
    char buffer[1024];
    memset(buffer, 0, sizeof(buffer));
    ssize_t bytesRead = recv(nSocket, buffer, sizeof(buffer) - 1, 0);
    if (bytesRead > 0) {
        receivedString = std::string(buffer);
    }
}

int main() {
    // Path to the face cascade XML file for face detection
    String face_cascade_path = "haarcascade_frontalface_default.xml";

    // Path to the directory containing the training images
    String training_dir = "training_data";

    // Create the LBPH face recognizer
    Ptr<cv::face::LBPHFaceRecognizer> recognizer = cv::face::LBPHFaceRecognizer::create();

    // Load the trained model
    recognizer->read("trained_model.xml");

    // Load the face cascade classifier
    CascadeClassifier face_cascade;
    face_cascade.load(face_cascade_path);

    // Initialize the camera
    VideoCapture camera(0);
    camera.set(CAP_PROP_FRAME_WIDTH, 640);   // Width
    camera.set(CAP_PROP_FRAME_HEIGHT, 480);  // Height

    // Font settings for displaying text on the image
    int font = FONT_HERSHEY_SIMPLEX;
    double font_scale = 1.0;
    Scalar font_color(0, 255, 0);  // Green

    // Mapping between labels and names
    std::map<int, std::string> label_name_map;
    label_name_map[0] = "PhuongA";
    label_name_map[1] = "Truc";
    // Add more mappings as per your training data
    
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket < 0) {
        std::cerr << "Error creating socket" << std::endl;
        return 1;
    }

    
    struct sockaddr_in serverAddress;
    serverAddress.sin_family = AF_INET;
    serverAddress.sin_addr.s_addr = INADDR_ANY;
    serverAddress.sin_port = htons(1239); // Replace with the appropriate port number

    if (bind(serverSocket, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0) {
        std::cerr << "Error binding socket" << std::endl;
        return 1;
    }

    // Listen for incoming connections
    listen(serverSocket, 1);

    // Accept a client connection
    
        // Close the client socket and server socket
    struct sockaddr_in clientAddress;
            socklen_t clientAddressSize = sizeof(clientAddress);
            int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddress, &clientAddressSize);
            if (clientSocket < 0) {
                std::cerr << "Error accepting client connection" << std::endl;
                return 1;
            }
            
            // Receive string from the client socket
            std::string receivedString;
    while (true){
            receiveStringFromSocket(clientSocket, receivedString);
            std::cout << "Received string: " << receivedString << std::endl;
            if (receivedString == "open_facerecog cpp")
            {
        while (true) {
            // Capture frame-by-frame from the camera
            
                Mat frame;
                camera >> frame;

                // Convert the frame to grayscale for face detection
                Mat gray;
                cvtColor(frame, gray, COLOR_BGR2GRAY);

                // Detect faces in the frame
                std::vector<Rect> faces;
                face_cascade.detectMultiScale(gray, faces, 1.1, 5, 0 | CASCADE_SCALE_IMAGE, Size(30, 30));

                // Process each detected face
                for (const auto& face : faces) {
                    // Extract the face region of interest (ROI)
                    Mat face_roi = gray(face);

                    // Recognize the face using the LBPH recognizer
                    int label = -1;
                    double confidence = 0.0;
                    recognizer->predict(face_roi, label, confidence);

                    // Get the name corresponding to the label
                    std::string name = "Unknown";
                    if (label_name_map.find(label) != label_name_map.end()) {
                        name = label_name_map[label];
                    }

                    // Display the predicted name and confidence level
                    std::string text = (confidence > 80 && confidence < 100) ?
                        format("%s | %.2f", name.c_str(), confidence) :
                        "Unknown";
                    putText(frame, text, Point(face.x, face.y - 10), font, font_scale, font_color, 2, LINE_AA);

                    // Draw a rectangle around the face
                    rectangle(frame, face, Scalar(0, 255, 0), 2);
                }

                // Display the resulting frame
                imshow("Face Recognition", frame);
            

            // Exit the loop if 'q' is pressed
            if (waitKey(1) == 'q') {
                break;
            }
            
        
        }
        
        
        
    }
}
    // Release the camera and close any open windows
    camera.release();
    destroyAllWindows();
    return 0;
}
